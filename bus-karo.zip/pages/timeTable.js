import React from 'react'

const timeTable = () => {
  return (
    <div>
      This is Time Table
    </div>
  )
}

export default timeTable
