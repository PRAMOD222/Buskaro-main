// pages/map.js

import { useState, useEffect } from 'react';
import firebase from 'firebase/app';
import 'firebase/database';
import { GoogleMap, Marker, LoadScript } from '@react-google-maps/api';

const MapPage = () => {
  const [markers, setMarkers] = useState([]);

  useEffect(() => {
    // Firebase configuration
    const firebaseConfig = {
      apiKey: 'AIzaSyCz7V5B1G4ZLflFlhjpxepPX1j7p-Rs1ZI',
      authDomain: 'gsp-tracker-ca6e5.firebaseapp.com',
      databaseURL: 'https://gsp-tracker-ca6e5-default-rtdb.firebaseio.com',
      projectId: 'gsp-tracker-ca6e5',
      storageBucket: 'gsp-tracker-ca6e5.appspot.com',
      messagingSenderId: '204637618654',
      appId: '1:204637618654:web:33f3d989739de752e81d4f',
    };

    // Initialize Firebase
    if (!firebase.apps.length) {
      firebase.initializeApp(firebaseConfig);
    }

    // Reference to your Firebase database
    const database = firebase.database();

    // Fetch data from Firebase
    const fetchData = () => {
      database.ref('/markers').once('value')
        .then(snapshot => {
          const data = snapshot.val();
          if (data) {
            const fetchedMarkers = Object.values(data);
            setMarkers(fetchedMarkers);
          }
        })
        .catch(error => {
          console.error("Error fetching data:", error);
        });
    };

    fetchData();

    // Clean up function
    return () => {
      // Close Firebase connection if necessary
    };
  }, []);

  return (
    <div style={{ height: '500px', width: '100%' }}>
      <LoadScript googleMapsApiKey="AIzaSyBIHv7Vci9zEHGqW9g244wdwHUFdvfC2Ds">
        <GoogleMap
          mapContainerStyle={{ height: '100%', width: '100%' }}
          center={{ lat: 0, lng: 0 }}
          zoom={2}
        >
          {markers.map(marker => (
            <Marker
              key={marker.id}
              position={{ lat: marker.lat, lng: marker.lng }}
            />
          ))}
        </GoogleMap>
      </LoadScript>
    </div>
  );
};

export default MapPage;
