import React from 'react'

const search = () => {
  return (
    <div>
      this is search page
    </div>
  )
}

export default search
