import React from 'react'

const busLocation = () => {
    return (
        <div>
            
        </div>
    )
}

export default busLocation
